# jinspector
Jinspector Joomla! Site Inspector
This plugin will gather information about your Joomla! installation, trigger the Find Updates option in your Joomla! installer at a pre specified interval and email you the information. You can specify a custom email address, or addresses or select a user group that should receive notifications. See the product page for more details https://joomlafixers.com/jinspector
