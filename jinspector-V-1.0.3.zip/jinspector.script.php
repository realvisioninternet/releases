<?php
/**
 * @package         Jinspector Joomla! Site Inspector
 * @version         1.0.3
 * @author          Realvision Internet Limited
 * @copyright       Copyright © 2017-2018 Realvision Internet Limited All Rights Reserved
 * @license 	    Licensed under the GNU General Public License version 3, or later, see license.txt
 * @link            https://joomlafixers.com/extensions/jinspector-joomla-site-inspector
 */
// no direct access
defined('_JEXEC') or die;


class plgSystemJinspectorInstallerScript
{
 
  function update( $parent ) {
	  
	    JFactory::getApplication()->enqueueMessage(JText::_('PLG_SYSTEM_JINSPECTOR_XML_UPDATE'), 'notice');
	    	   
  }
 function install( $parent ) {
	 
	 JFactory::getApplication()->enqueueMessage(JText::_('PLG_SYSTEM_JINSPECTOR_XML_INSTALL'), 'notice');

 }

   
} 
