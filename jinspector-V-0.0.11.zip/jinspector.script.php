<?php
/**
 * @package         Jinspector Joomla! Site Inspector
 * @version         0.0.11
 * 
 * @author          Realvision Internet Limited
 * @link            https://joomlafixers.com/extensions/jinspector-joomla-site-inspector
 * @copyright       Copyright © 2017 Realvision Internet Limited All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
// no direct access
defined('_JEXEC') or die;


class plgSystemJinspectorInstallerScript
{
 
  function update( $parent ) {
	  
	   
	    JError::raiseNotice( 100, JText::_( 'PLG_SYSTEM_JINSPECTOR_XML_UPDATE' ) );
	   
  }
 function install( $parent ) {
	 
	
	 JError::raiseNotice( 100, JText::_( 'PLG_SYSTEM_JINSPECTOR_XML_INSTALL' ) );

	 
  }

   
} 
