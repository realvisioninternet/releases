<?php
/**
 * @package         Jinspector Joomla! Site Inspector
 * @version         1.0.4
 * 
 * @author          Realvision Internet Limited
 * @link            https://joomlafixers.com/extensions/jinspector-joomla-site-inspector
 * @copyright       Copyright © 2017 Realvision Internet Limited All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
// no direct access
defined('_JEXEC') or die;
//print_r( $_SERVER);
// Load language 


class plgSystemJinspector extends JPlugin
{
    private $recipients = array();

    /**
     * @return bool
     */
     
    
    public function onAfterRender()
    {
        if (!$this->doIHaveToRun()) {
             return false;
         }
         

        
        $lang = JFactory::getLanguage();
        $lang->load('plg_system_jinspector', JPATH_ADMINISTRATOR, 'en-GB', true);
        $lang->load('plg_system_jinspector', JPATH_ADMINISTRATOR, 'en-GB', true);
             
             // clear the cache to avoid issues in the backend
        $cache = JFactory::getCache();
        $cache->clean('com_plugins');

		
		try {
			$updates = $this->checkForUpdates();
		} catch (UnexpectedValueException $e) {
			// let us send a mail to the user
			$title = JText::_('PLG_SYSTEM_JINSPECTOR_ERROR_TITLE');
			$body = JText::_('ERROR_MSG');
			$body .= "<br>" . JText::_('INFO_MESSAGE') . "<br>";
			$this->sendMail($title, $body);
			$this->setLastRunTimestamp();
			// and exit...
			
			return false;
		}

        if (count($updates)) {
            if (count($updates) == 1) {
                $title = JText::_('SINGLE_UPDATE_TITLE');
            } else {
                $title = count($updates).' '.JText::_('MULTIPLE_UPDATE_TITLE');
            }
            
            $absolute_url  = JURI::root();
          	$body  = $this->getSysteminfo();
            $body .= JText::_('UPDATES_REQUIRED');
            foreach ($updates as $value) {
                $body .= JText::_('UPDATE_FOR') . ': '
                    . $value->name . ' ' . JText::_('EXT_VERSION') . ': '
                    . $value->version . ' ' . JText::_('EXT_FOUND') . "<br>";
            }
            $body .= "<br>" . JText::_('TO_APPLY_UPDATES')
                . $absolute_url . ' ' . JText::_('GO_TO_PLUGIN') . "<br>";

        } else if ((!count($updates)) && (($this->params->get('mailto_noresult') == 0))) {
             $title = JText::_('NO_UPDATES');
             $body = JText::_('NO_UPDATES_AT') . ' ' . $absolute_url . "<br>";;
        }

        if (count($updates) ||
            ((!count($updates)) && (($this->params->get('mailto_noresult') == 0)))) {

            $body .= JText::_('PLUGIN_BODY');
            $body .= $this->nextUpdateText();
            $body .= "<br>" . JText::_('NOTIFICATION_TEXT') . "<br>";

            $this->sendMail($title, $body);
        }

  
        $this->setLastRunTimestamp();

        return true;
    }

    /**
     * @return string - get next update text
     */
    private function nextUpdateText()
    {
        $body = '<h3>'.JText::_("NEXT_NOTIFICATION") . ' ';

        switch ($this->params->get('notification_period')) {
            case "24":
                $body .= JText::_('TOMORROW_TEXT') . '.';
                break;
            case "168":
                $body .= JText::_('ONE_WEEK_TEXT') . '.';
                break;
            case "336":
                $body .= JText::_('TWO_WEEK_TEXT') . '.';
                break;
            case "672":
                $body .= JText::_('FOUR_WEEK_TEXT') . '.';
                break;
        }
		
		echo $body .= '</h3>';
		
        return $body;
    }

    /**
     * @param $title - the email title
     * @param $body - the email body
     */
    private function sendMail($title, $body)
    {
        $app = JFactory::getApplication();
        $recipients = $this->getRecipients();
        $mail = JFactory::getMailer();
        $mail->addRecipient($recipients);
        $mail->setSender(array($app->getCfg('mailfrom'), $app->getCfg('fromname')));
        $mail->setSubject($title);
        $mail->setBody($body);
        $mail->Send();
    }

    /**
     *
     * @return array - all recepients
     */
    private function getRecipients()
    {
        $emails = array();

        if (!count($this->recipients)) {
            if ($this->params->get('mailto_admins', 0)) {
                $groups = $this->params->get('mailto_admins');
                $tmp_emails = $this->getEmailsForUsersInGroups($groups);

                if (!is_array($emails)) {
                    $emails = array();
                }
                $emails = array_merge($tmp_emails, $emails);
            }

            if ((int)$this->params->get('mailto_custom') == 1 && $this->params->get('custom_email') != "") {
                $tmp_emails = explode(';', $this->params->get('custom_email'));

                if (!is_array($emails)) {
                    $emails = array();
                }
                $emails = array_merge($tmp_emails, $emails);
            }

            $tmp = array();
            foreach ($emails AS $r)
            {
                if (in_array($r, $tmp) || trim($r) == "") {
                    continue;
                }
                else {
                    $this->recipients[] = $r;
                    $tmp[] = $r;
                }
            }
        }

        return $this->recipients;
    }

    /**
     * checks if there are updates available
     * @return object - the updates
     */
    private function checkForUpdates()
    {
        jimport('joomla.updater.updater');
        $updater = JUpdater::getInstance();
        $updater->findUpdates(0, 0);

        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__updates')->where('extension_id != 0');
        $db->setQuery($query);

        return $db->loadObjectList();
    }

    /**
     * Check the last execution timestamp, stored in the component's configuration.
     * this function is copied from the asexpirationnotify plugin so all credits go to
     * Nicholas K. Dionysopoulos / Akeeba Ltd
     * @return bool
     */
    private function doIHaveToRun()
    {
        $params = $this->params;
        $lastRunUnix = $params->get('jinspectore_timestamp', 0);
        $dateInfo = getdate($lastRunUnix);
        $nextRunUnix = mktime(0, 0, 0, $dateInfo['mon'], $dateInfo['mday'], $dateInfo['year']);
        $nextRunUnix += $params->get('notification_period', 24) * 3600;
        $now = time();
        return ($now >= $nextRunUnix);
    }

    /**
     * Save the timestamp of this plugin's last run
     * this function is copied from the asexpirationnotify plugin so all credits go to
     * Nicholas K. Dionysopoulos / Akeeba Ltd
     *
     */
    private function setLastRunTimestamp()
    {
        $lastRun = time();
        $params = $this->params;
        $params->set('jinspectore_timestamp', $lastRun);

        $db = JFactory::getDBO();

        $data = $params->toString('JSON');
        $query = $db->getQuery(true);
        $query->update('#__extensions');
        $query->set('params = ' . $db->Quote($data));
        $query->where('element = "jinspector" AND type = "plugin"');
        $db->setQuery($query);
        $db->query();
    }

    /**
     *
     * @param array $groups - the user group
     * @return mixed
     */
    private function getEmailsForUsersInGroups(array $groups)
    {

        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('a.email');
        $query->from('#__user_usergroup_map AS map');
        $query->leftJoin('#__users AS a ON a.id = map.user_id');
        $query->where('map.group_id IN (' . implode(',', $groups) . ')');

        $db->setQuery($query);
        return $db->loadColumn();
    }
    function getSysteminfo()
    {
		$uri = & JFactory::getURI();
        $absolute_url = JURI::root();
       	$app  = JFactory::getApplication();
			$version     = new JVersion;
		    $versionText = $version->getLongVersion();
		    $phpversion = JText::_('CURRENT_PHP_VERSION').phpversion();
            $html = '<h3>'.JText::_('JOOMLAFIXERS_SITECECK').$absolute_url. '  on '. date('Y-m-d h:i:s').'</h3>';
            $html .= JText::_('SYSTEM_INFO').$versionText.'<br>';
            $html .= 'PHP Version:'.$phpversion;
            $html .=  '<br>'.JText::_('WEB_SERVER').$_SERVER['SERVER_NAME'].'/'.$_SERVER['SERVER_SOFTWARE'];
			$html .= '<br>'.JText::_('WERSERVER_TO_PHP').$_SERVER['GATEWAY_INTERFACE'];
			$html .=  '<br>'.JText::_('ACTIVE_THEME').$app->getTemplate();
		return $html;
	}

}
